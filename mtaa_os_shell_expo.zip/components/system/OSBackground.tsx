/**
 * MTAA OS — ONE Global Background (React Native)
 * NO duplicate gradients. NO nested backgrounds. NO multiple overlays.
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';

export function OSBackground() {
  return (
    <View style={styles.container} pointerEvents="none">
      <View style={styles.base} />
      <View style={styles.gradient} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { ...StyleSheet.absoluteFillObject, zIndex: 0 },
  base: { ...StyleSheet.absoluteFillObject, backgroundColor: '#020617' },
  gradient: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'transparent',
    // Radial gradient simulated with a large blurred view
    opacity: 0.15,
  },
});
