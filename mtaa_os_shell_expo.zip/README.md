# MTAA OS Shell — Expo Router / React Native

## What Changed

All `next/navigation` imports replaced with `expo-router`.
All web-only components rewritten for React Native (`react-native` imports, StyleSheet, TouchableOpacity, View, Text, ScrollView).

## Files

```
app/(os)/
├── _layout.tsx          ← OS shell with SplashScreen intercept
├── home.tsx             ← OS Launcher (ScrollView)
├── launcher.tsx         ← Full screen app launcher (search + categories)
└── system-status.tsx    ← System diagnostics

components/system/
├── SplashScreen.tsx     ← RN kernel boot layer with Animated
├── OSBackground.tsx     ← RN background (View-based)
├── OSTopBar.tsx         ← RN top bar (profile + status + icons)
├── OSNavigation.tsx     ← RN bottom nav (5 tabs)
├── OSLauncherGrid.tsx   ← RN app grid from registry
├── SystemPanels.tsx     ← RN 4-panel system view
└── QuickActions.tsx     ← RN quick action bar

hooks/
├── useKernelBoot.ts     ← Uses EXPO_PUBLIC_ env vars
├── useKernelState.ts
├── useInstalledApps.ts
├── useAuth.ts           ← STUB: replace with your Supabase auth
├── useRecentActivity.ts ← STUB: replace with Supabase query
├── useCivicAlerts.ts    ← STUB: replace with Supabase query
└── useTransactionActivity.ts ← STUB: replace with Supabase query
```

## Env Vars

Use Expo's public env prefix:

```bash
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

## Replace Stubs

| Stub | Replace With |
|---|---|
| `hooks/useAuth.ts` | Your existing `useAuth` hook (Supabase) |
| `hooks/useRecentActivity.ts` | Query `activity_log` or `kernel_events` |
| `hooks/useCivicAlerts.ts` | Query `civic_emergencies` or alerts table |
| `hooks/useTransactionActivity.ts` | Query `transactions` or `wallet_transactions` |

## Wiring

The `app/(os)/_layout.tsx` is the shell. Ensure your `app/_layout.tsx` (root) doesn't conflict:

```tsx
// app/_layout.tsx — minimal root, let (os)/_layout handle the shell
import { Stack } from 'expo-router';

export default function RootLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}
```

## Important

- `app/(os)/_layout.tsx` uses `<View style={styles.main}>` as the content area. Expo Router's `<Slot />` or `<Stack />` should render inside it.
- If your root layout already wraps everything, you may need to move the shell logic there instead.
- The `OSNavigation` is `position: 'absolute', bottom: 0` — ensure your scroll views have `paddingBottom: 100` to avoid overlap.
