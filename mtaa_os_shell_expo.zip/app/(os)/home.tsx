/**
 * MTAA OS — Home / OS Launcher (Expo Router)
 */

import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { OSLauncherGrid } from '@/components/system/OSLauncherGrid';
import { SystemPanels } from '@/components/system/SystemPanels';
import { QuickActions } from '@/components/system/QuickActions';

export default function HomePage() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <OSLauncherGrid />
      <SystemPanels />
      <QuickActions />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16, paddingBottom: 100 },
});
