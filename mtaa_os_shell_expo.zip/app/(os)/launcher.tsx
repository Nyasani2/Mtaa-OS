/**
 * MTAA OS — Full Screen Launcher (Expo Router)
 */

import React, { useState, useMemo } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useInstalledApps } from '@/hooks/useInstalledApps';
import { AppManifest } from '@/lib/kernel/registry/kernel-registry';

export default function LauncherPage() {
  const router = useRouter();
  const { apps, isLoading } = useInstalledApps();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = useMemo(() => {
    const cats = new Set(apps.map((a) => a.domain));
    return ['all', ...Array.from(cats)];
  }, [apps]);

  const filtered = useMemo(() => {
    return apps.filter((app) => {
      const matchesSearch = app.name.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === 'all' || app.domain === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [apps, search, activeCategory]);

  if (isLoading) {
    return (
      <View style={styles.center}>
        <View style={styles.spinner} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchWrap}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search apps..."
          placeholderTextColor="#64748b"
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')} style={styles.clearBtn}>
            <Text style={styles.clearText}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Categories */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.catScroll}>
        <View style={styles.catRow}>
          {categories.map((cat) => (
            <TouchableOpacity
              key={cat}
              onPress={() => setActiveCategory(cat)}
              style={[styles.catBtn, activeCategory === cat && styles.catBtnActive]}
            >
              <Text style={[styles.catText, activeCategory === cat && styles.catTextActive]}>
                {cat === 'all' ? 'All Apps' : cat}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* App Grid */}
      <ScrollView contentContainerStyle={styles.grid}>
        {filtered.map((app) => (
          <AppLauncherCard key={app.id} app={app} onLaunch={() => router.push(`/${app.domain}`)} />
        ))}
        {filtered.length === 0 && (
          <Text style={styles.empty}>No apps found</Text>
        )}
      </ScrollView>
    </View>
  );
}

function AppLauncherCard({ app, onLaunch }: { app: AppManifest; onLaunch: () => void }) {
  return (
    <TouchableOpacity onPress={onLaunch} style={styles.card} activeOpacity={0.7}>
      <View style={[styles.iconBox, { backgroundColor: app.color || '#475569' }]}>
        <Text style={styles.iconText}>{app.icon || '◆'}</Text>
      </View>
      <Text style={styles.cardLabel}>{app.name}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  spinner: { width: 32, height: 32, borderRadius: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' },
  searchWrap: { position: 'relative', marginBottom: 12 },
  searchInput: { backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, color: '#fff', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  clearBtn: { position: 'absolute', right: 12, top: 12 },
  clearText: { color: 'rgba(255,255,255,0.5)', fontSize: 16 },
  catScroll: { marginBottom: 12 },
  catRow: { flexDirection: 'row', gap: 8, paddingRight: 16 },
  catBtn: { paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.1)' },
  catBtnActive: { backgroundColor: '#fff' },
  catText: { color: 'rgba(255,255,255,0.7)', fontSize: 13 },
  catTextActive: { color: '#0f172a', fontWeight: '600' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  card: { width: '30%', alignItems: 'center', padding: 8 },
  iconBox: { width: 56, height: 56, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  iconText: { fontSize: 24 },
  cardLabel: { fontSize: 11, color: 'rgba(255,255,255,0.8)', textAlign: 'center' },
  empty: { color: 'rgba(255,255,255,0.5)', textAlign: 'center', marginTop: 40, width: '100%' },
});
