/**
 * MTAA OS — Shell Layout (Expo Router)
 * ONE global OS background system. ONE layout wrapper. ONE theme manager.
 */

import React, { useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { usePathname } from 'expo-router';
import { SplashScreen } from '@/components/system/SplashScreen';
import { OSTopBar } from '@/components/system/OSTopBar';
import { OSBackground } from '@/components/system/OSBackground';
import { OSNavigation } from '@/components/system/OSNavigation';
import { useKernelBoot } from '@/hooks/useKernelBoot';

export default function OSShellLayout() {
  const pathname = usePathname();
  const { booted, phase, error } = useKernelBoot();
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    if (!booted) return;
    const timer = setTimeout(() => setShowSplash(false), 800);
    return () => clearTimeout(timer);
  }, [booted]);

  // Show splash on initial load until boot completes
  if (showSplash && (pathname === '/' || pathname === '/(os)')) {
    return (
      <View style={StyleSheet.absoluteFill}>
        <SplashScreen phase={phase} error={error} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <OSBackground />
      <View style={styles.shell}>
        <OSTopBar />
        <View style={styles.main}>
          {/* Expo Router Slot renders children here */}
        </View>
        <OSNavigation />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617', // slate-950
  },
  shell: {
    flex: 1,
    position: 'relative',
    zIndex: 10,
  },
  main: {
    flex: 1,
  },
});
