/**
 * MTAA OS — useKernelBoot Hook (Expo / React Native)
 */

import { useEffect, useState, useCallback } from 'react';
import { KernelRuntime } from '@/lib/kernel/runtime/kernel-runtime';
import { useAuth } from './useAuth';

export interface BootState {
  booted: boolean;
  phase: string;
  error: string | null;
  progress: number;
}

export function useKernelBoot(): BootState {
  const { user, isLoading: authLoading } = useAuth();
  const [booted, setBooted] = useState(false);
  const [phase, setPhase] = useState('idle');
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const boot = useCallback(async () => {
    if (authLoading) return;

    try {
      const runtime = KernelRuntime.getInstance({
        supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL!,
        supabaseKey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
        environment: (process.env.NODE_ENV as any) || 'development',
      });

      const eventSystem = runtime.getEventSystem();
      const unsub = eventSystem.subscribe({
        id: 'boot-phase-listener',
        domain: 'kernel',
        types: ['kernel.runtime.booted', 'kernel.runtime.boot_failed'],
        handler: (event) => {
          if (event.type === 'kernel.runtime.booted') {
            setBooted(true);
            setPhase('ready');
            setProgress(100);
          } else if (event.type === 'kernel.runtime.boot_failed') {
            setError(event.payload?.error || 'Boot failed');
            setPhase('degraded');
          }
        },
      });

      await runtime.boot();
      return () => unsub();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setPhase('degraded');
    }
  }, [authLoading]);

  useEffect(() => {
    boot();
  }, [boot]);

  return { booted, phase, error, progress };
}
