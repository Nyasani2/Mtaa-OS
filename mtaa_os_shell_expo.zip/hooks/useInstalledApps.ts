/**
 * MTAA OS — useInstalledApps Hook (Expo / React Native)
 */

import { useEffect, useState } from 'react';
import { KernelRuntime } from '@/lib/kernel/runtime/kernel-runtime';
import { AppManifest } from '@/lib/kernel/registry/kernel-registry';

export function useInstalledApps() {
  const [apps, setApps] = useState<AppManifest[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let runtime: KernelRuntime;
    try {
      runtime = KernelRuntime.getInstance();
    } catch {
      setIsLoading(false);
      return;
    }

    const registry = runtime.getRegistry();

    const load = () => {
      const mounted = registry.getMountedApps();
      const manifests = mounted.map((m) => m.manifest);
      setApps(manifests);
      setIsLoading(false);
    };

    load();

    const eventSystem = runtime.getEventSystem();
    const unsub = eventSystem.subscribe({
      id: 'installed-apps-listener',
      domain: 'kernel',
      types: ['kernel.app.mounted', 'kernel.app.unmounted', 'kernel.app.installed'],
      handler: load,
    });

    return () => unsub();
  }, []);

  return { apps, isLoading };
}
