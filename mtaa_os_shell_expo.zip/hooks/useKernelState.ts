/**
 * MTAA OS — useKernelState Hook (Expo / React Native)
 */

import { useEffect, useState } from 'react';
import { KernelRuntime } from '@/lib/kernel/runtime/kernel-runtime';

export function useKernelState() {
  const [phase, setPhase] = useState('idle');
  const [healthScore, setHealthScore] = useState(100);
  const [activeApps, setActiveApps] = useState(0);
  const [eventThroughput, setEventThroughput] = useState(0);

  useEffect(() => {
    let runtime: KernelRuntime;
    try {
      runtime = KernelRuntime.getInstance();
    } catch {
      return;
    }

    const eventSystem = runtime.getEventSystem();

    const update = () => {
      const state = runtime.getState();
      setPhase(state.phase);
      setHealthScore(state.healthScore);
      setActiveApps(state.activeApps.length);
      setEventThroughput(state.eventThroughput);
    };

    update();

    const unsub = eventSystem.subscribe({
      id: 'kernel-state-listener',
      domain: 'kernel',
      types: ['kernel.runtime.heartbeat'],
      handler: update,
    });

    const interval = setInterval(update, 5000);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  return { phase, healthScore, activeApps, eventThroughput };
}
