# MTAA OS — Home + Splash Consolidation

## What This Is

Replaces fragmented app home architecture with a true MTAA OS shell.

## Architecture

```
Splash Screen
    ↓
Kernel Boot (lifecycle → registry → events → realtime → scheduler → apps → watchdog)
    ↓
App Registry Mount
    ↓
OS Launcher (home.tsx)
    ↓
Installed Apps Runtime
```

## Files

```
app/(os)/
├── _layout.tsx          ← ONE OS shell layout (background + top bar + nav)
├── home.tsx             ← OS Launcher (NOT a social feed)
├── launcher.tsx         ← Full screen app launcher with search/categories
└── system-status.tsx    ← Deep diagnostics page

components/system/
├── SplashScreen.tsx     ← Kernel initialization layer (not cosmetic)
├── OSBackground.tsx     ← ONE global background system
├── OSTopBar.tsx         ← Profile + kernel status + realtime + notifications
├── OSNavigation.tsx     ← ONE consolidated bottom nav
├── OSLauncherGrid.tsx   ← Installed app grid from registry
├── SystemPanels.tsx     ← Recent activity + civic alerts + transactions + realtime
├── QuickActions.tsx     ← Send / Receive / Scan / Pay / Top Up
└── SystemHealthDashboard.tsx (from kernel consolidation)

hooks/
├── useKernelBoot.ts     ← Full kernel boot lifecycle management
├── useKernelState.ts    ← Live kernel health/phase/metrics
├── useInstalledApps.ts  ← Apps from registry (NOT hardcoded)
├── useAuth.ts           ← Auth interface stub (replace with yours)
├── useRecentActivity.ts ← Activity feed data
├── useCivicAlerts.ts    ← Civic alert feed
└── useTransactionActivity.ts ← Transaction feed
```

## Splash Rules

- Splash IS the kernel initialization layer
- Flow: open app → kernel boot → validate session → load installed apps → restore state → initialize realtime → mount launcher
- Only ONE splash lifecycle. No duplicates.

## Home Rules

- Home is the **MTAA OS Launcher**, not a social feed
- Apps load from registry dynamically
- System panels show: recent activity, civic alerts, transactions, realtime status
- Quick actions: Send, Receive, Scan, Pay, Top Up

## Background Rules

- ONE global OS background system
- ONE layout wrapper
- ONE theme manager
- NO duplicate gradients, nested backgrounds, multiple overlays

## Navigation Rules

- ONE consolidated bottom nav: Home / Apps / Wallet / Messages / Profile
- NO old dashboard nav, duplicated tabs, disconnected launchers

## Wallet Rules

- Wallet is a core system service mounted through registry
- ONE canonical wallet entry at /wallet
- NO duplicate wallet routes

## App Store Rules

- App Store is a runtime installer + lifecycle manager + permissions manager
- Installed apps mount dynamically into launcher

## Wiring

In your root layout (e.g., `app/layout.tsx`), wrap with the OS shell:

```tsx
import OSShellLayout from './(os)/_layout';

export default function RootLayout({ children }) {
  return <OSShellLayout>{children}</OSShellLayout>;
}
```

Or use Next.js route groups: place all routes under `app/(os)/` so the shell layout applies automatically.

## Replace Stubs

- `hooks/useAuth.ts` — replace with your actual Supabase auth hook
- `hooks/useRecentActivity.ts` — replace with actual Supabase query
- `hooks/useCivicAlerts.ts` — replace with actual Supabase query
- `hooks/useTransactionActivity.ts` — replace with actual Supabase query
