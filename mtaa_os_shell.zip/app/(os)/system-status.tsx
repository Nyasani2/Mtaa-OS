/**
 * MTAA OS — System Status Page
 * Deep diagnostics: kernel, registry, events, realtime, mounted apps.
 */

'use client';

import React from 'react';
import { SystemHealthDashboard } from '@/components/system/SystemHealthDashboard';

export default function SystemStatusPage() {
  return <SystemHealthDashboard />;
}
