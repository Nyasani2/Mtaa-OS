/**
 * MTAA OS — Home / OS Launcher
 * NOT a social feed. This is the operating system launcher.
 *
 * TOP AREA: profile, kernel status, realtime state, notifications
 * CORE: installed app grid from registry
 * PANELS: recent activity, civic alerts, transactions, system alerts, quick actions
 */

'use client';

import React from 'react';
import { OSLauncherGrid } from '@/components/system/OSLauncherGrid';
import { SystemPanels } from '@/components/system/SystemPanels';
import { QuickActions } from '@/components/system/QuickActions';

export default function HomePage() {
  return (
    <div className="flex flex-col gap-6 p-4 pb-24">
      {/* App launcher grid — loads from registry, NOT hardcoded */}
      <OSLauncherGrid />

      {/* System panels: recent activity, civic alerts, transactions, realtime alerts */}
      <SystemPanels />

      {/* Quick actions bar */}
      <QuickActions />
    </div>
  );
}
