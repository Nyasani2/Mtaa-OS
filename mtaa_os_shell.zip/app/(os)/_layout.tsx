/**
 * MTAA OS — Shell Layout
 * ONE global OS background system. ONE layout wrapper. ONE theme manager.
 * NO duplicate gradients. NO nested backgrounds. NO multiple overlays.
 */

'use client';

import React, { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { KernelRuntime } from '@/lib/kernel/runtime/kernel-runtime';
import { KernelEventSystem } from '@/lib/kernel/events/kernel-event-system';
import { KernelRegistry } from '@/lib/kernel/registry/kernel-registry';
import { SplashScreen } from '@/components/system/SplashScreen';
import { OSTopBar } from '@/components/system/OSTopBar';
import { OSBackground } from '@/components/system/OSBackground';
import { OSNavigation } from '@/components/system/OSNavigation';
import { useKernelBoot } from '@/hooks/useKernelBoot';

export default function OSShellLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { booted, phase, error } = useKernelBoot();
  const [showSplash, setShowSplash] = useState(true);

  // Splash minimum display time + boot completion
  useEffect(() => {
    if (!booted) return;
    const timer = setTimeout(() => setShowSplash(false), 800);
    return () => clearTimeout(timer);
  }, [booted]);

  // Show splash on initial load, hide on boot complete
  if (showSplash && pathname === '/') {
    return (
      <div className="fixed inset-0 z-[9999]">
        <SplashScreen phase={phase} error={error} />
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full relative overflow-hidden">
      {/* ONE global background — no duplicates, no nesting */}
      <OSBackground />

      {/* ONE OS shell */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top status area: profile + kernel status + realtime + notifications */}
        <OSTopBar />

        {/* Main content area */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>

        {/* ONE consolidated navigation — no old dashboard nav, no duplicated tabs */}
        <OSNavigation />
      </div>
    </div>
  );
}
