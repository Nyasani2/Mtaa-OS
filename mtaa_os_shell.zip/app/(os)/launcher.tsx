/**
 * MTAA OS — Full Screen Launcher
 * Expanded view of all installed apps with search and categories.
 */

'use client';

import React, { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useInstalledApps } from '@/hooks/useInstalledApps';
import { AppManifest } from '@/lib/kernel/registry/kernel-registry';

export default function LauncherPage() {
  const router = useRouter();
  const { apps, isLoading } = useInstalledApps();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = useMemo(() => {
    const cats = new Set(apps.map((a) => a.domain));
    return ['all', ...Array.from(cats)];
  }, [apps]);

  const filtered = useMemo(() => {
    return apps.filter((app) => {
      const matchesSearch = app.name.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === 'all' || app.domain === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [apps, search, activeCategory]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="animate-spin w-8 h-8 border-2 border-white/30 border-t-white rounded-full" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 p-4 pb-24">
      {/* Search */}
      <div className="relative">
        <input
          type="text"
          placeholder="Search apps..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 outline-none focus:border-white/40"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white"
          >
            ✕
          </button>
        )}
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors ${
              activeCategory === cat
                ? 'bg-white text-slate-900 font-medium'
                : 'bg-white/10 text-white/70 hover:bg-white/20'
            }`}
          >
            {cat === 'all' ? 'All Apps' : cat}
          </button>
        ))}
      </div>

      {/* App Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
        {filtered.map((app) => (
          <AppLauncherCard key={app.id} app={app} onLaunch={() => router.push(`/${app.domain}`)} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center text-white/50 py-12">
          No apps found
        </div>
      )}
    </div>
  );
}

function AppLauncherCard({ app, onLaunch }: { app: AppManifest; onLaunch: () => void }) {
  return (
    <button
      onClick={onLaunch}
      className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-white/10 transition-colors group"
    >
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-lg"
        style={{ backgroundColor: app.color || '#3b82f6' }}
      >
        {app.icon || '◆'}
      </div>
      <span className="text-xs text-white/80 text-center leading-tight group-hover:text-white">
        {app.name}
      </span>
    </button>
  );
}
