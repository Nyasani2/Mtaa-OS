/**
 * MTAA OS — ONE Global Background System
 * NO duplicate gradients. NO nested backgrounds. NO multiple overlays.
 */

'use client';

import React from 'react';

export function OSBackground() {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none">
      {/* Base layer */}
      <div className="absolute inset-0 bg-slate-950" />

      {/* ONE subtle gradient — no duplicates */}
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          background: 'radial-gradient(ellipse 80% 50% at 50% -20%, rgba(59, 130, 246, 0.15), transparent)',
        }}
      />

      {/* ONE subtle grid — no duplicates */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />
    </div>
  );
}
