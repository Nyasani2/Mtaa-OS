/**
 * MTAA OS — ONE Consolidated Navigation
 * NO old dashboard nav. NO duplicated tabs. NO disconnected launchers.
 */

'use client';

import React from 'react';
import { useRouter, usePathname } from 'next/navigation';

const NAV_ITEMS = [
  { path: '/', label: 'Home', icon: '⌂' },
  { path: '/launcher', label: 'Apps', icon: '◈' },
  { path: '/wallet', label: 'Wallet', icon: '◉' },
  { path: '/messages', label: 'Messages', icon: '✉' },
  { path: '/profile', label: 'Profile', icon: '◐' },
];

export function OSNavigation() {
  const router = useRouter();
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900/90 backdrop-blur-lg border-t border-white/10">
      <div className="flex items-center justify-around px-2 py-2 max-w-lg mx-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname === item.path || pathname.startsWith(item.path + '/');
          return (
            <button
              key={item.path}
              onClick={() => router.push(item.path)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-colors ${
                isActive ? 'text-blue-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="text-lg leading-none">{item.icon}</span>
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
