/**
 * MTAA OS — System Panels
 * Recent activity, civic alerts, transaction activity, realtime alerts.
 */

'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useRecentActivity } from '@/hooks/useRecentActivity';
import { useCivicAlerts } from '@/hooks/useCivicAlerts';
import { useTransactionActivity } from '@/hooks/useTransactionActivity';

export function SystemPanels() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <RecentActivityPanel />
      <CivicAlertsPanel />
      <TransactionPanel />
      <RealtimeAlertsPanel />
    </div>
  );
}

function RecentActivityPanel() {
  const { activities, isLoading } = useRecentActivity();
  const router = useRouter();

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white/80">Recent Activity</h3>
        <button onClick={() => router.push('/activity')} className="text-xs text-blue-400">View All</button>
      </div>
      <div className="space-y-2">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-10 bg-white/5 rounded-lg animate-pulse" />
          ))
        ) : activities.length === 0 ? (
          <div className="text-xs text-slate-500 py-4 text-center">No recent activity</div>
        ) : (
          activities.slice(0, 4).map((a) => (
            <div key={a.id} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-sm">
                {a.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-white truncate">{a.title}</div>
                <div className="text-xs text-slate-400">{a.time}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function CivicAlertsPanel() {
  const { alerts, isLoading } = useCivicAlerts();
  const router = useRouter();

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white/80">Civic Alerts</h3>
        <button onClick={() => router.push('/civic/alerts')} className="text-xs text-blue-400">View All</button>
      </div>
      <div className="space-y-2">
        {isLoading ? (
          Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="h-10 bg-white/5 rounded-lg animate-pulse" />
          ))
        ) : alerts.length === 0 ? (
          <div className="text-xs text-slate-500 py-4 text-center">No active alerts</div>
        ) : (
          alerts.slice(0, 3).map((alert) => (
            <div
              key={alert.id}
              className={`flex items-center gap-3 py-2 px-3 rounded-lg ${
                alert.severity === 'critical' ? 'bg-red-500/10 border border-red-500/20' : 'bg-white/5'
              }`}
            >
              <span className="text-lg">{alert.severity === 'critical' ? '⚠' : 'ℹ'}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-white truncate">{alert.message}</div>
                <div className="text-xs text-slate-400">{alert.source}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function TransactionPanel() {
  const { transactions, isLoading } = useTransactionActivity();
  const router = useRouter();

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white/80">Transactions</h3>
        <button onClick={() => router.push('/wallet/transactions')} className="text-xs text-blue-400">View All</button>
      </div>
      <div className="space-y-2">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-10 bg-white/5 rounded-lg animate-pulse" />
          ))
        ) : transactions.length === 0 ? (
          <div className="text-xs text-slate-500 py-4 text-center">No recent transactions</div>
        ) : (
          transactions.slice(0, 4).map((tx) => (
            <div key={tx.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${
                  tx.type === 'in' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  {tx.type === 'in' ? '↓' : '↑'}
                </div>
                <div>
                  <div className="text-sm text-white">{tx.description}</div>
                  <div className="text-xs text-slate-400">{tx.time}</div>
                </div>
              </div>
              <div className={`text-sm font-medium ${tx.type === 'in' ? 'text-emerald-400' : 'text-red-400'}`}>
                {tx.type === 'in' ? '+' : '-'}{tx.amount}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function RealtimeAlertsPanel() {
  const [alerts, setAlerts] = React.useState<{ id: string; message: string; time: string }[]>([]);

  React.useEffect(() => {
    // Subscribe to kernel realtime alerts
    const interval = setInterval(() => {
      // This would connect to actual kernel realtime
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white/80">System Status</h3>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-emerald-400">Live</span>
        </div>
      </div>
      <div className="space-y-2">
        {alerts.length === 0 ? (
          <div className="flex items-center gap-3 py-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
              <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <div className="text-sm text-white">All systems operational</div>
              <div className="text-xs text-slate-400">Kernel, registry, and realtime connected</div>
            </div>
          </div>
        ) : (
          alerts.map((a) => (
            <div key={a.id} className="text-sm text-white py-1">{a.message}</div>
          ))
        )}
      </div>
    </div>
  );
}
