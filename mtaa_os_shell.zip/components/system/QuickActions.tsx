/**
 * MTAA OS — Quick Actions
 * Fast-access buttons for common operations.
 */

'use client';

import React from 'react';
import { useRouter } from 'next/navigation';

const QUICK_ACTIONS = [
  { label: 'Send', icon: '↑', path: '/wallet/send', color: '#3b82f6' },
  { label: 'Receive', icon: '↓', path: '/wallet/receive', color: '#10b981' },
  { label: 'Scan', icon: '◫', path: '/scan', color: '#8b5cf6' },
  { label: 'Pay', icon: '◉', path: '/wallet/pay', color: '#f59e0b' },
  { label: 'Top Up', icon: '+', path: '/wallet/topup', color: '#ec4899' },
];

export function QuickActions() {
  const router = useRouter();

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-4">
      <h3 className="text-sm font-semibold text-white/80 mb-3">Quick Actions</h3>
      <div className="flex justify-between gap-2">
        {QUICK_ACTIONS.map((action) => (
          <button
            key={action.label}
            onClick={() => router.push(action.path)}
            className="flex flex-col items-center gap-1.5 flex-1 py-3 rounded-xl hover:bg-white/10 transition-colors active:scale-95"
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-lg"
              style={{ backgroundColor: `${action.color}20`, color: action.color }}
            >
              {action.icon}
            </div>
            <span className="text-[11px] text-white/70">{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
