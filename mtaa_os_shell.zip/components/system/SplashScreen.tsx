/**
 * MTAA OS — Splash Screen
 * NOT cosmetic. This IS the kernel initialization layer.
 *
 * FLOW:
 *   open app → kernel boot → validate session → load installed apps
 *   → restore state → initialize realtime → mount launcher
 */

'use client';

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface SplashScreenProps {
  phase: string;
  error: string | null;
}

const PHASE_LABELS: Record<string, string> = {
  idle: 'Initializing...',
  booting: 'Booting kernel...',
  lifecycle: 'Activating lifecycle...',
  registry: 'Loading registry...',
  events: 'Initializing events...',
  realtime: 'Connecting realtime...',
  scheduler: 'Starting scheduler...',
  apps: 'Mounting apps...',
  watchdog: 'Activating watchdog...',
  ready: 'System ready',
  degraded: 'System degraded',
  shutdown: 'Shutting down...',
};

export function SplashScreen({ phase, error }: SplashScreenProps) {
  const [dots, setDots] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      setDots((prev) => (prev.length >= 3 ? '' : prev + '.'));
    }, 500);
    return () => clearInterval(interval);
  }, []);

  const isReady = phase === 'ready';
  const isError = !!error;

  return (
    <div className="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center z-[9999]">
      {/* ONE background — no duplicates */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-800/40 via-slate-950 to-slate-950" />

      <AnimatePresence mode="wait">
        {!isReady ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="relative flex flex-col items-center gap-8"
          >
            {/* Logo */}
            <div className="relative">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-2xl shadow-blue-500/20">
                <span className="text-4xl font-bold text-white">M</span>
              </div>
              <motion.div
                className="absolute inset-0 rounded-3xl border-2 border-blue-400/30"
                animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>

            {/* Brand */}
            <div className="text-center">
              <h1 className="text-2xl font-bold text-white tracking-tight">MTAA OS</h1>
              <p className="text-sm text-slate-400 mt-1">National Digital Infrastructure</p>
            </div>

            {/* Phase indicator */}
            <div className="flex flex-col items-center gap-3 min-h-[80px]">
              {isError ? (
                <div className="text-red-400 text-sm max-w-xs text-center">
                  ⚠ {error}
                </div>
              ) : (
                <>
                  <div className="text-sm text-slate-300 font-mono">
                    {PHASE_LABELS[phase] || phase}{dots}
                  </div>
                  {/* Progress bar */}
                  <div className="w-48 h-1 bg-slate-800 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                      initial={{ width: '0%' }}
                      animate={{ width: getPhaseProgress(phase) }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </>
              )}
            </div>

            {/* Version */}
            <div className="text-xs text-slate-600 font-mono">v10.0.0-kernel</div>
          </motion.div>
        ) : (
          <motion.div
            key="ready"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-white text-lg font-medium"
          >
            Welcome
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function getPhaseProgress(phase: string): string {
  const phases = ['idle', 'booting', 'lifecycle', 'registry', 'events', 'realtime', 'scheduler', 'apps', 'watchdog', 'ready'];
  const idx = phases.indexOf(phase);
  if (idx === -1) return '0%';
  return `${((idx + 1) / phases.length) * 100}%`;
}
