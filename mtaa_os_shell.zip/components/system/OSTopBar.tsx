/**
 * MTAA OS — Top Bar
 * Profile + kernel status + realtime connection + notifications.
 */

'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useKernelState } from '@/hooks/useKernelState';
import { useAuth } from '@/hooks/useAuth';

export function OSTopBar() {
  const router = useRouter();
  const { phase, healthScore } = useKernelState();
  const { user, profile } = useAuth();

  const isOnline = phase === 'ready';
  const isDegraded = healthScore < 80;

  return (
    <header className="flex items-center justify-between px-4 py-3 bg-white/5 backdrop-blur-md border-b border-white/10">
      {/* Left: Profile */}
      <button
        onClick={() => router.push('/profile')}
        className="flex items-center gap-3 hover:bg-white/10 rounded-lg px-2 py-1 transition-colors"
      >
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-xs font-bold text-white">
          {profile?.full_name?.[0] || user?.email?.[0] || '?'}
        </div>
        <div className="hidden sm:block text-left">
          <div className="text-sm text-white font-medium leading-tight">
            {profile?.full_name || user?.email?.split('@')[0] || 'Guest'}
          </div>
          <div className="text-xs text-slate-400 leading-tight">
            {profile?.kyc_level ? `KYC L${profile.kyc_level}` : 'Unverified'}
          </div>
        </div>
      </button>

      {/* Center: Kernel Status */}
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
        <span className="text-xs text-slate-400 hidden sm:inline">
          {isOnline ? 'Online' : isDegraded ? 'Degraded' : 'Booting...'}
        </span>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {/* Notifications */}
        <button
          onClick={() => router.push('/notifications')}
          className="relative p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <svg className="w-5 h-5 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
        </button>

        {/* System Status */}
        <button
          onClick={() => router.push('/system-status')}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <svg className="w-5 h-5 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
        </button>
      </div>
    </header>
  );
}
