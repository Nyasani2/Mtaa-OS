/**
 * MTAA OS — Launcher Grid
 * Core system apps loaded from registry. NOT hardcoded manually.
 *
 * Apps: Wallet, App Store, Civic, Streets, MTAXI, Hookup, Documents,
 *       Treasury, Revenue, Health
 */

'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useInstalledApps } from '@/hooks/useInstalledApps';
import { AppManifest } from '@/lib/kernel/registry/kernel-registry';

export function OSLauncherGrid() {
  const router = useRouter();
  const { apps, isLoading } = useInstalledApps();

  if (isLoading) {
    return (
      <div className="grid grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="flex flex-col items-center gap-2 animate-pulse">
            <div className="w-14 h-14 rounded-2xl bg-white/10" />
            <div className="w-16 h-3 bg-white/10 rounded" />
          </div>
        ))}
      </div>
    );
  }

  // Sort: system apps first, then alphabetically
  const sorted = [...apps].sort((a, b) => {
    if (a.systemApp && !b.systemApp) return -1;
    if (!a.systemApp && b.systemApp) return 1;
    return a.name.localeCompare(b.name);
  });

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold text-white/80 uppercase tracking-wider">Apps</h2>
        <button
          onClick={() => router.push('/launcher')}
          className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
        >
          See All →
        </button>
      </div>

      <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
        {sorted.slice(0, 10).map((app) => (
          <AppIcon key={app.id} app={app} onClick={() => router.push(`/${app.domain}`)} />
        ))}
      </div>
    </div>
  );
}

function AppIcon({ app, onClick }: { app: AppManifest; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1.5 p-2 rounded-xl hover:bg-white/10 transition-colors group active:scale-95"
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center text-xl shadow-md transition-transform group-hover:scale-105"
        style={{ backgroundColor: app.color || '#475569' }}
      >
        {app.icon || '◆'}
      </div>
      <span className="text-[11px] text-white/70 text-center leading-tight group-hover:text-white">
        {app.name}
      </span>
    </button>
  );
}
