/**
 * MTAA OS - Kernel Architecture Enforcement Layer
 */

type Layer = "app" | "domain" | "kernel" | "app-store" | "hooks" | "services" | "unknown";

interface Violation {
  from: string;
  to: string;
  reason: string;
}

export function detectLayer(path: string): Layer {
  if (path.includes("/app/")) return "app";
  if (path.includes("/domains/")) return "domain";
  if (path.includes("/lib/kernel")) return "kernel";
  if (path.includes("/apps-store/")) return "app-store";
  if (path.includes("/hooks/")) return "hooks";
  if (path.includes("/services/")) return "services";
  return "unknown";
}

function getDomain(path: string): string | null {
  const match = path.match(/\/domains\/([^\/]+)/);
  return match?.[1] ?? null;
}

function sameDomain(from: string, to: string): boolean {
  const f = getDomain(from);
  const t = getDomain(to);
  return f !== null && f === t;
}

export function validateImport(from: string, to: string): Violation | null {
  const fromLayer = detectLayer(from);
  const toLayer = detectLayer(to);

  if (fromLayer === "app" && (toLayer === "services" || toLayer === "kernel")) {
    return { from, to, reason: "UI layer cannot access services/kernel directly" };
  }

  if (fromLayer === "domain" && toLayer === "domain" && !sameDomain(from, to)) {
    return { from, to, reason: "Cross-domain imports are forbidden" };
  }

  if (toLayer === "app-store" && fromLayer !== "kernel") {
    return { from, to, reason: "Only kernel can access app-store" };
  }

  if (toLayer === "kernel" && fromLayer !== "kernel") {
    return { from, to, reason: "Kernel is system-only" };
  }

  return null;
}

export function enforceImport(from: string, to: string) {
  const v = validateImport(from, to);
  if (v) throw new Error(`[MTAA KERNEL BLOCK] ${v.reason}`);
  return true;
}
